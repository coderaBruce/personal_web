var tape = require("tape"),
    lasso = require("../");

tape("lasso() returns the answer to the ultimate question of life, the universe, and everything.", function(test) {
  //test.equal(lasso.lasso(), 42);
  test.end();
});
